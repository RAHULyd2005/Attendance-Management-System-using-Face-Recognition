 bg="black",
    fg="yellow",